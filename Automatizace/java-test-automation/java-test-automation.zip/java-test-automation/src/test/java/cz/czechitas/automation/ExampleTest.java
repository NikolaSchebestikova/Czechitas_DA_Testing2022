package cz.czechitas.automation;

import org.junit.jupiter.api.Test;

/**
 * Example test class for functionality showcase
 *
 * @author Jiri Koudelka
 * @since 1.0.0
 */
final class ExampleTest extends TestRunner {

    @Test
    void overKontaktniWwwAdresu() {
        prohlizec.jdiDoSekceKontakt();
        overeni.overAdresuWwwStranky("www.czechitas.cz");
    }

    @Test
    void overUspesnePrihlaseni() {
        prohlizec.klikniNaTlacitkoPrihlasit();
        prohlizec.vyplnEmail("admin@czechitas-app.loc");
        prohlizec.vyplnHeslo("Czechitas123");
        prohlizec.provedPrihlaseni();
        overeni.overPrihlaseniUzivatele();
    }
    @Test
    void ukol1() {
        prohlizec.jdiDoSekceNavodyAFormulareProRodice();
        prohlizec.cekejNekolikVterin(5);

    }
    @Test
    void ukol2() {
        prohlizec.jdiDoSekceNavodyAFormulareProUcitele();
        prohlizec.jdiDoSekceObjednavkaProMSZS();
        prohlizec.cekejNekolikVterin(5);
        prohlizec.vyberMoznostPrimestskyTabor();
        prohlizec.cekejNekolikVterin(5);
    }

    @Test
    void ukol3() {
       prohlizec.jdiDoSekceDomu();
       prohlizec.jdiDoSekceNavodyAFormulareProRodice();
       prohlizec.jdiDoSekceVytvorPrihlaskuProRodice();
       prohlizec.jdiDoSekceNavodyAFormulareProUcitele();
       prohlizec.jdiDoSekceObjednavkaProMSZS();
       prohlizec.jdiDoSekceKontakt();
    }
    @Test
    void ukol4() {
        prohlizec.jdiDoSekceNavodyAFormulareProUcitele();
        prohlizec.jdiDoSekceObjednavkaProMSZS();
        prohlizec.cekejNekolikVterin(5);
        prohlizec.vyplnICO("22834958");
    }
    @Test
    void ukol5() {
        prohlizec.klikniNaTlacitkoPrihlasit();
        prohlizec.vyplnEmail("n.schebestikova@seznam.cz");
        prohlizec.vyplnHeslo("Cameronik123");
        prohlizec.provedPrihlaseni();
        overeni.overPrihlaseniUzivatele();
    }

    @Test
    void assertionukol6() {
    overeni.overExistenciDlazdiceProgramovani();

    }
    @Test
    void assertionukol7() {
        prohlizec.jdiDoSekceVytvorPrihlaskuProRodice();
        overeni.overPritomnostTlacitkaZaregistrujteSe();

    }
    @Test
    void assertionukol8() {
        prohlizec.klikniNaTlacitkoPrihlasit();
        prohlizec.vyplnEmail("n.schebestikova@seznam.cz");
        prohlizec.vyplnHeslo("Cameronik123");
        prohlizec.provedPrihlaseni();
        overeni.overPrihlaseniUzivatele();
        prohlizec.otevriDetailPrvniPrihlasky();
        overeni.overZpusobUhradyPrihlasky("Bankovní převod");

    }

}

